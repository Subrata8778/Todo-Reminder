-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 17 Bulan Mei 2024 pada 05.33
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `todo`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `type` enum('Image','Video') NOT NULL,
  `url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `gallery`
--

INSERT INTO `gallery` (`id`, `type`, `url`) VALUES
(1, 'Image', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSAUZ30kPK_5dtDnX3kTTxwMq2rPPnP15ro_w&s'),
(2, 'Image', 'https://tokofoto.co/wp-content/uploads/2022/07/Definisi-Foto-yang-Bagus.jpg'),
(4, 'Video', 'https://video.blender.org/download/videos/6d447a73-5491-42e9-8ee1-fc16f817a385-1080.mp4');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tasks`
--

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `due` datetime NOT NULL,
  `status` enum('Todo','InProgress','Done') NOT NULL,
  `file` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tasks`
--

INSERT INTO `tasks` (`id`, `username`, `title`, `description`, `due`, `status`, `file`) VALUES
(1, 'as', 'hahaha', 'ajsjnjs', '2024-05-11 03:18:00', 'Done', ''),
(2, 'as', 'dd', 'dwdw', '2024-05-17 15:40:00', 'Done', ''),
(3, 'as', 'adfdfe', 'effe', '2024-05-23 03:41:00', 'Done', ''),
(4, 'as', 'yeay', 'aks', '2024-05-16 08:17:00', 'InProgress', ''),
(5, 'as', 'makan', 'jajaj', '2024-05-31 16:23:00', 'Todo', ''),
(6, 'as', 'bsbsb', 'bsbeb', '2024-05-16 05:27:00', 'Todo', ''),
(7, 'as', 'hrh', 'hsjsks', '2024-05-16 05:27:00', 'Todo', ''),
(8, 'as', 'hdhe', 'bse', '2024-05-16 05:27:00', 'Todo', ''),
(9, 'as', 'wdd', 'dwwd', '2024-05-17 04:28:00', 'Todo', ''),
(10, 'as', 'wdddwd', 'dwwd', '2024-05-17 04:30:00', 'Todo', ''),
(11, 'as', 'cobaa', 'aaaa', '2024-05-17 05:53:00', 'Todo', ''),
(12, 'as', 'cobaashsh', 'aaaa', '2024-05-17 06:05:00', 'Todo', ''),
(13, 'as', 'gaga', 'aa', '2024-05-17 06:12:00', 'Todo', ''),
(14, 'as', 'dada', 'dafafag', '2024-05-17 06:53:00', 'Todo', ''),
(15, 'as', 'dadfgff', 'ffy', '2024-05-17 06:52:00', 'Todo', ''),
(16, 'as', 'ztyxyx', 'xyg', '2024-05-17 07:26:00', 'Todo', ''),
(17, 'as', 'hhahaks', 'jsajs', '2024-05-17 12:14:00', 'Todo', ''),
(18, 'as', 'jndcjnc', 'djjsdjd', '2024-05-17 12:18:00', 'Todo', ''),
(19, 'as', 'Kerja', 'Fitur tambahan', '2024-05-17 12:14:00', 'Todo', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`username`, `name`, `password`) VALUES
('a', 'a', '123456'),
('as', 'Subrata', 'as'),
('ayam', 'ayam', 'ayam'),
('Subrata', 'Subrata', 'Subrata'),
('yaya', 'yaya', 'yaya');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tasks_username_foreign` (`username`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `tasks_username_foreign` FOREIGN KEY (`username`) REFERENCES `users` (`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
