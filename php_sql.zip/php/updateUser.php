<?php
include 'db.php';

$username = $_POST['username'];
$newName = $_POST['newName'];

$sql = "UPDATE users SET name='$newName' WHERE username='$username'";

$response = array();
if ($conn->query($sql) === TRUE) {
    $response["status"] = "success";
    $response["message"] = "Record updated successfully";
} else {
    $response["status"] = "error";
    $response["message"] = "Error updating record: " . $conn->error;
}

echo json_encode($response);

$conn->close();
?>
