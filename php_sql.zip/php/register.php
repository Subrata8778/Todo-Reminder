<?php
include 'db.php';

$username = $_POST['username'];
$name = $_POST['name'];
$password = $_POST['password'];

$sql = "INSERT INTO users (username, name, password) VALUES ('$username', '$name', '$password')";
if ($conn->query($sql) === TRUE) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error", "message" => "Error: " . $conn->error]);
}
?>
