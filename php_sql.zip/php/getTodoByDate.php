<?php
include 'db.php';

// Periksa apakah parameter 'username' dan 'date' ada
$username = isset($_GET['username']) ? $_GET['username'] : '';
$date = isset($_GET['date']) ? $_GET['date'] : '';

// Set header ke JSON
header('Content-Type: application/json');

// Siapkan query SQL dengan parameter
$sql = "SELECT * FROM tasks WHERE username = ? AND due LIKE ?";
$stmt = $conn->prepare($sql);

// Periksa apakah pernyataan SQL telah berhasil disiapkan
if ($stmt) {
    $dateParam = "$date%";
    $stmt->bind_param("ss", $username, $dateParam);
    $stmt->execute();
    $result = $stmt->get_result();

    $tasks = array();
    while ($row = $result->fetch_assoc()) {
        $tasks[] = $row;
    }

    // Kirimkan hasil dalam format JSON
    echo json_encode($tasks);

    $stmt->close();
} else {
    // Kirimkan pesan error yang lebih detail
    echo json_encode(array("error" => "Failed to prepare SQL statement.", "sql_error" => $conn->error));
}

$conn->close();
?>
