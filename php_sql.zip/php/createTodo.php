<?php
include 'db.php';

$username = $_POST['username'];
$title = $_POST['title'];
$description = $_POST['description'];
$due = $_POST['due'];
$status = $_POST['status'];
$filePath = '';

// Proses upload file jika ada
if (isset($_FILES['file']) && $_FILES['file']['error'] == UPLOAD_ERR_OK) {
    $file = $_FILES['file'];
    $uploadDir = 'uploads/';
    $filePath = $uploadDir . basename($file['name']);
    if (move_uploaded_file($file['tmp_name'], $filePath)) {
        $filePath = $conn->real_escape_string($filePath);
    } else {
        $filePath = ''; // Atau bisa berikan pesan error
    }
}

// Simpan todo ke database
$stmt = $conn->prepare("INSERT INTO tasks (username, title, description, due, status, file) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssss", $username, $title, $description, $due, $status, $filePath);
$response = array();
if ($stmt->execute()) {
    $response["status"] = "success";
    $response["message"] = "Todo created successfully";
} else {
    $response["status"] = "error";
    $response["message"] = "Error creating todo: " . $stmt->error;
}

echo json_encode($response);

$stmt->close();
$conn->close();
?>
