<?php
include 'db.php';

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    echo json_encode([
        "status" => "success",
        "user" => [
            "username" => $user['username'],
            "name" => $user['name']
        ]
    ]);
} else {
    echo json_encode(["status" => "error", "message" => "Invalid login credentials"]);
}

$conn->close();
?>
