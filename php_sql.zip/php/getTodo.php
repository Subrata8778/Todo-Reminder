<?php
include 'db.php';

// Periksa apakah parameter 'username', 'status', dan 'limit' ada
$username = isset($_GET['username']) ? $_GET['username'] : '';
$status = isset($_GET['status']) ? $_GET['status'] : '';
$limit = isset($_GET['limit']) ? intval($_GET['limit']) : 3;

// Siapkan query SQL dengan parameter
$sql = "SELECT * FROM tasks WHERE username = ? AND status = ? LIMIT ?";
$stmt = $conn->prepare($sql);

// Set header ke JSON
header('Content-Type: application/json');

// Periksa apakah pernyataan SQL telah berhasil disiapkan
if ($stmt) {
    $stmt->bind_param("ssi", $username, $status, $limit);
    $stmt->execute();
    $result = $stmt->get_result();

    $tasks = array();
    while ($row = $result->fetch_assoc()) {
        $tasks[] = $row;
    }

    // Kirimkan hasil dalam format JSON
    echo json_encode($tasks);

    $stmt->close();
} else {
    echo json_encode(array("error" => "Failed to prepare SQL statement."));
}

$conn->close();
?>
