<?php
include 'db.php';

// Query to fetch images and videos
$sql = "SELECT id, type, url FROM gallery";
$result = $conn->query($sql);

$items = array();
while($row = $result->fetch_assoc()) {
    $items[] = $row;
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($items);
?>
