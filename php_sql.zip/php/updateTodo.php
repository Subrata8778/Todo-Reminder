<?php
include 'db.php';

$id = $_POST['id'];
$status = $_POST['status'];

$sql = "UPDATE tasks SET status='$status' WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();
?>
